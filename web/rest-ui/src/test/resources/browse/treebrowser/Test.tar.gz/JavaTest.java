pubic class JavaTest
{

}
